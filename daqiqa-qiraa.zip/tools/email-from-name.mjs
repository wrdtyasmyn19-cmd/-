// الاستخدام: node tools/email-from-name.mjs "اسم المشرفة"
import { webcrypto as c } from 'node:crypto';
const n = process.argv[2].trim().replace(/\s+/g, ' ');
const h = await c.subtle.digest('SHA-256', new TextEncoder().encode(n));
console.log('t' + [...new Uint8Array(h)].slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join('') + '@daqiqa.app');
