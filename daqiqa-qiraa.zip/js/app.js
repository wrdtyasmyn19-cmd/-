import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged, createUserWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFirestore, doc, getDoc, setDoc, addDoc, updateDoc, collection, query, where, getDocs, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { firebaseConfig } from '../firebase-config.js';
import { ACTIVITIES, STAGES } from './data-lab.js';

const MASTERY = 0.8; // نسبة الإجابات الصحيحة التي تُعدّ نجاحًا في الأداء
const app = initializeApp(firebaseConfig), auth = getAuth(app), db = getFirestore(app);
const $ = document.getElementById('app'); let me = null;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const dt = t => t?.toDate ? t.toDate().toLocaleString('ar-OM') : '';
const topbar = () => `<div class="row noprint"><b>${esc(me.name)} ${me.role === 'supervisor' ? '(مشرفة)' : ''}</b><button class="alt" id="out">خروج</button></div>`;
const bindOut = () => document.getElementById('out').onclick = () => signOut(auth);

const attemptsQ = s => me.role === 'supervisor' ? query(collection(db, 'attempts'), where('studentId', '==', s.id))
  : query(collection(db, 'attempts'), where('studentId', '==', s.id), where('teacherId', '==', me.uid));

// اسم المعلمة لا يُستخدم وحده؛ نشتق منه بريدًا داخليًا ثابتًا والرمز السري هو كلمة المرور
async function emailOf(name) {
  const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(name.trim().replace(/\s+/g, ' ')));
  return 't' + [...new Uint8Array(h)].slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join('') + '@daqiqa.app';
}

onAuthStateChanged(auth, async u => {
  if (!u) { me = null; return login(); }
  const s = await getDoc(doc(db, 'users', u.uid));
  if (!s.exists() || s.data().active === false) { await signOut(auth); return login('الحساب غير مفعّل. تواصلي مع المشرفة.'); }
  me = { uid: u.uid, ...s.data() };
  me.role === 'supervisor' ? supHome() : teacherHome();
});

function login(msg = '') {
  $.innerHTML = `<div class="card"><h1>دقيقة قراءة</h1><p>سجّلي الدخول باسمك ورمزك السري</p>
  <input id="n" placeholder="الاسم" autocomplete="username"><input id="p" type="password" placeholder="الرمز السري" autocomplete="current-password">
  <button id="go">دخول</button><p class="msg" id="m">${esc(msg)}</p></div>`;
  document.getElementById('go').onclick = async () => {
    const n = document.getElementById('n').value, p = document.getElementById('p').value;
    try { await signInWithEmailAndPassword(auth, await emailOf(n), p); }
    catch { document.getElementById('m').textContent = 'الاسم أو الرمز غير صحيح'; }
  };
}

async function teacherHome() {
  const ss = await getDocs(query(collection(db, 'students'), where('teacherId', '==', me.uid)));
  const rows = ss.docs.map(d => ({ id: d.id, ...d.data() }));
  $.innerHTML = `${topbar()}<div class="card"><h2>طلبتي</h2>${rows.map(s => `<div class="row"><span>${esc(s.name)} <span class="tag">الصف ${esc(s.grade)} ${esc(s.section)}</span></span><button data-s="${s.id}">ابدئي</button></div>`).join('') || '<p>لم تضيفي طلبة بعد.</p>'}</div>
  <div class="card"><h3>إضافة طالب</h3><input id="sn" placeholder="اسم الطالب"><select id="sg">${[1, 2, 3, 4].map(g => `<option>${g}</option>`).join('')}</select><input id="ss" placeholder="الشعبة (اختياري، مثل أ)"><button id="add">إضافة</button></div>`;
  bindOut();
  document.getElementById('add').onclick = async () => {
    const name = document.getElementById('sn').value.trim(); if (!name) return;
    await addDoc(collection(db, 'students'), { name, grade: document.getElementById('sg').value, section: document.getElementById('ss').value.trim(), teacherId: me.uid, teacherName: me.name, createdAt: serverTimestamp() });
    teacherHome();
  };
  $.querySelectorAll('[data-s]').forEach(b => b.onclick = () => studentPage(rows.find(s => s.id === b.dataset.s)));
}

async function studentPage(s) {
  const at = await getDocs(attemptsQ(s));
  const last = {}; at.docs.map(d => d.data()).sort((a, b) => (a.date?.seconds || 0) - (b.date?.seconds || 0)).forEach(a => last[a.activityId] = a);
  let html = `${topbar()}<div class="row"><h2>${esc(s.name)}</h2><span><button id="rp">تقرير الطالب</button> <button class="alt" id="back">رجوع</button></span></div><h3>قراءة الكلمات: مختبر الكلمات</h3>`;
  for (const st of Object.keys(STAGES)) {
    html += `<div class="card"><h3>${STAGES[st]}</h3>` + ACTIVITIES.filter(a => a.stage == st).map(a => {
      const l = last[a.id];
      return `<div class="row"><span>${a.title} <span class="tag">ص${a.page}</span> ${l ? `<span class="tag">آخر محاولة: ${l.correct}/${l.total}</span>` : ''}</span><button data-a="${a.id}">ابدئي</button></div>`;
    }).join('') + '</div>';
  }
  $.innerHTML = html; bindOut();
  document.getElementById('back').onclick = teacherHome;
  document.getElementById('rp').onclick = () => report(s, () => studentPage(s));
  $.querySelectorAll('[data-a]').forEach(b => b.onclick = () => play(s, ACTIVITIES.find(a => a.id === b.dataset.a)));
}

function play(s, act) {
  let i = 0; const answers = [], t0 = Date.now();
  const show = () => {
    if (i >= act.items.length) return finish();
    const it = act.items[i];
    $.innerHTML = `<div class="card"><div class="row"><b>${act.title}</b><span>${i + 1} / ${act.items.length}</span></div><p>${act.instr}</p>
    <div class="big">${esc(it.prompt)}</div><div style="text-align:center">${it.options.map(o => `<button class="opt" data-o="${esc(o)}">${esc(o)}</button>`).join('')}</div></div>`;
    $.querySelectorAll('.opt').forEach(b => b.onclick = () => {
      const ok = b.dataset.o === it.answer; answers.push({ item: it.prompt, picked: b.dataset.o, ok });
      b.classList.add(ok ? 'ok' : 'bad'); $.querySelectorAll('.opt').forEach(x => x.disabled = true);
      setTimeout(() => { i++; show(); }, 700);
    });
  };
  const finish = () => {
    const correct = answers.filter(a => a.ok).length, total = answers.length, seconds = Math.round((Date.now() - t0) / 1000);
    const mastered = correct / total >= MASTERY;
    $.innerHTML = `<div class="card"><h2>انتهى النشاط</h2><div class="big">${correct} / ${total}</div>
    <p>${mastered ? 'أداء جيد، حققت نسبة الإتقان' : 'يحتاج إلى تدريب إضافي'}</p>
    <textarea id="note" rows="3" placeholder="ملاحظات المعلمة (اختياري)"></textarea>
    <button id="save">حفظ النتيجة</button> <button class="alt" id="skip">رجوع بدون حفظ</button></div>`;
    document.getElementById('skip').onclick = () => studentPage(s);
    document.getElementById('save').onclick = async () => {
      await addDoc(collection(db, 'attempts'), { studentId: s.id, studentName: s.name, grade: s.grade, teacherId: me.uid, teacherName: me.name,
        activityId: act.id, activityTitle: act.title, source: act.src, date: serverTimestamp(), answers, correct, wrong: total - correct, total, seconds,
        completed: true, mastered, result: mastered ? 'أداء جيد' : 'يحتاج تدريبًا', mode: 'auto', note: document.getElementById('note').value.trim() });
      studentPage(s);
    };
  };
  show();
}

async function supHome(tab = 'teachers') {
  $.innerHTML = `${topbar()}<div class="row noprint"><button data-t="teachers" class="${tab === 'teachers' ? '' : 'alt'}">المعلمات</button><button data-t="students" class="${tab === 'students' ? '' : 'alt'}">الطلبة</button></div><div id="pane">…</div>`;
  bindOut(); $.querySelectorAll('[data-t]').forEach(b => b.onclick = () => supHome(b.dataset.t));
  const pane = document.getElementById('pane');
  if (tab === 'teachers') {
    const us = (await getDocs(query(collection(db, 'users'), where('role', '==', 'teacher')))).docs.map(d => ({ id: d.id, ...d.data() }));
    pane.innerHTML = `<div class="card"><h3>المعلمات</h3>${us.map(u => `<div class="row"><span>${esc(u.name)} <span class="tag">${u.active ? 'مفعّل' : 'معطّل'}</span></span><button class="alt" data-u="${u.id}" data-a="${u.active}">${u.active ? 'تعطيل' : 'تفعيل'}</button></div>`).join('') || '<p>لا توجد معلمات.</p>'}</div>
    <div class="card"><h3>إضافة معلمة</h3><input id="tn" placeholder="الاسم"><input id="tp" placeholder="الرمز السري (6 أحرف أو أرقام على الأقل)"><button id="ta">إنشاء الحساب</button><p class="msg" id="tm"></p></div>`;
    pane.querySelectorAll('[data-u]').forEach(b => b.onclick = async () => { await updateDoc(doc(db, 'users', b.dataset.u), { active: b.dataset.a !== 'true' }); supHome('teachers'); });
    document.getElementById('ta').onclick = async () => {
      const name = document.getElementById('tn').value.trim(), pin = document.getElementById('tp').value;
      try {
        const sec = initializeApp(firebaseConfig, 'sec'), sa = getAuth(sec); // تطبيق ثانٍ حتى لا تخرج المشرفة من حسابها
        const cr = await createUserWithEmailAndPassword(sa, await emailOf(name), pin); await signOut(sa);
        await setDoc(doc(db, 'users', cr.user.uid), { name, role: 'teacher', active: true, createdAt: serverTimestamp() });
        supHome('teachers');
      } catch (e) { document.getElementById('tm').textContent = 'تعذّر الإنشاء: ' + e.code; }
    };
  } else {
    const ss = (await getDocs(collection(db, 'students'))).docs.map(d => ({ id: d.id, ...d.data() }));
    pane.innerHTML = `<div class="card"><h3>جميع الطلبة</h3><input id="q" placeholder="بحث باسم الطالب أو المعلمة"><div id="list"></div></div><div id="att"></div>`;
    const draw = () => { const q = document.getElementById('q').value.trim();
      document.getElementById('list').innerHTML = ss.filter(s => !q || (s.name + s.teacherName).includes(q)).map(s => `<div class="row"><span>${esc(s.name)} <span class="tag">الصف ${esc(s.grade)}</span> <span class="tag">${esc(s.teacherName)}</span></span><button class="alt" data-s="${s.id}">ملف الطالب</button></div>`).join('');
      pane.querySelectorAll('[data-s]').forEach(b => b.onclick = () => attempts(ss.find(s => s.id === b.dataset.s))); };
    document.getElementById('q').oninput = draw; draw();
  }
}

async function attempts(s) {
  const a = (await getDocs(query(collection(db, 'attempts'), where('studentId', '==', s.id)))).docs.map(d => d.data()).sort((x, y) => (y.date?.seconds || 0) - (x.date?.seconds || 0));
  document.getElementById('att').innerHTML = `<div class="card"><div class="row"><h3>محاولات ${esc(s.name)}</h3><button id="rp2">تقرير الطالب</button></div><table><tr><th>التاريخ</th><th>النشاط</th><th>المصدر</th><th>النتيجة</th><th>الزمن</th><th>ملاحظة المعلمة</th></tr>
  ${a.map(x => `<tr><td>${dt(x.date)}</td><td>${esc(x.activityTitle)}</td><td>${esc(x.source.file)} ص${x.source.page}</td><td>${x.correct}/${x.total} (${esc(x.result)})</td><td>${x.seconds}ث</td><td>${esc(x.note)}</td></tr>`).join('') || '<tr><td colspan="6">لا توجد محاولات.</td></tr>'}</table></div>`;
  document.getElementById('rp2').onclick = () => report(s, () => supHome('students'));
}

async function report(s, back) {
  const all = (await getDocs(attemptsQ(s))).docs.map(d => d.data()).sort((a, b) => (a.date?.seconds || 0) - (b.date?.seconds || 0));
  $.innerHTML = `${topbar()}<div class="row noprint"><button class="alt" id="rb">رجوع</button><button id="pr">طباعة / حفظ PDF</button></div>
  <div class="card noprint"><div class="row"><label>من <input type="date" id="df"></label><label>إلى <input type="date" id="dto"></label><button id="ap">تطبيق الفترة</button></div></div><div id="rep"></div>`;
  bindOut(); document.getElementById('rb').onclick = back; document.getElementById('pr').onclick = () => window.print();
  const draw = () => {
    const f = document.getElementById('df').value, t = document.getElementById('dto').value;
    const a = all.filter(x => { const d = x.date?.toDate?.(); return !d || ((!f || d >= new Date(f)) && (!t || d <= new Date(t + 'T23:59:59'))); });
    const by = {}; a.forEach(x => (by[x.activityId] ||= []).push(x));
    const ids = Object.keys(by), last = id => by[id][by[id].length - 1];
    const names = list => list.map(id => esc(last(id).activityTitle)).join('، ') || 'لا يوجد بعد';
    document.getElementById('rep').innerHTML = `<div class="card"><h2>تقرير إنجاز الطالب</h2>
    <p>الاسم: <b>${esc(s.name)}</b> | الصف: ${esc(s.grade)} ${esc(s.section)} | معلمة الصف: ${esc(s.teacherName)}</p>
    <p>الفترة: ${f || 'من البداية'} إلى ${t || 'اليوم'} | عدد المحاولات: ${a.length} | تاريخ الإصدار: ${new Date().toLocaleDateString('ar-OM')}</p>
    <h3>الأنشطة التي نفذها الطالب</h3><table><tr><th>النشاط</th><th>المصدر</th><th>المحاولات</th><th>أول نتيجة</th><th>آخر نتيجة</th><th>الحالة</th></tr>
    ${ids.map(id => { const l = by[id], z = last(id); return `<tr><td>${esc(z.activityTitle)}</td><td>${esc(z.source.file)} ص${z.source.page}</td><td>${l.length}</td><td>${l[0].correct}/${l[0].total}</td><td>${z.correct}/${z.total}</td><td>${z.mastered ? 'حقق الإتقان' : 'يحتاج تدريبًا'}</td></tr>`; }).join('') || '<tr><td colspan="6">لا توجد محاولات في هذه الفترة.</td></tr>'}</table>
    <h3>مهارات أظهر فيها تقدمًا</h3><p>${names(ids.filter(id => last(id).mastered))}</p>
    <h3>مهارات تحتاج إلى تدريب إضافي</h3><p>${names(ids.filter(id => !last(id).mastered))}</p>
    <h3>ملاحظات معلمة الصف</h3><ul>${a.filter(x => x.note).map(x => `<li>${dt(x.date)}: ${esc(x.note)}</li>`).join('') || '<li>لا توجد ملاحظات</li>'}</ul>
    <h3>ملاحظات معلمة صعوبات التعلم وتوصيات المتابعة</h3><div style="min-height:100px;border:1px dashed var(--line);border-radius:12px"></div>
    <p class="tag">إكمال النشاط لا يعني إتقان المهارة. الحالة تعتمد على نسبة الإجابات الصحيحة (80% فأكثر) في آخر محاولة.</p></div>`;
  };
  document.getElementById('ap').onclick = draw; draw();
}
