// ضعي هنا إعدادات مشروع Firebase (Project settings > Your apps > Web app)
export const firebaseConfig = {
  apiKey: "PUT_API_KEY", authDomain: "PROJECT.firebaseapp.com",
  projectId: "PROJECT", appId: "PUT_APP_ID"
};
